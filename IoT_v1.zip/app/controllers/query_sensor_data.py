def handle_query_sensor_data():
    return {}